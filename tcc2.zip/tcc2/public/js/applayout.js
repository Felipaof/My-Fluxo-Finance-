// navbar.js
const user_navbar = JSON.parse(localStorage.getItem("loggedUser")) || { nome: "Usuário" };

// Navbar
const navbarHTML = `
<nav class="navbar">
    <div class="navbar-left">
        <img src="/img/MFF.jpg" alt="Logo My Fluxo Finance" class="logo">
        <span class="app-name">My Fluxo Finance</span>
    </div>
    <div class="navbar-right">
        <div class="user-menu">
            <img src="https://ui-avatars.com/api/?name=${user_navbar.nome}" alt="Usuário" class="user-avatar">
            <span class="user-name">${user_navbar.nome}</span>
            <i class="fas fa-chevron-down"></i>
            <div class="dropdown-menu">
                <a href="#"><i class="fas fa-user"></i> Perfil</a>
                <a href="#"><i class="fas fa-cog"></i> Configurações</a>
                <a href="/login" id="logout"><i class="fas fa-sign-out-alt"></i> Sair</a>
            </div>
        </div>
    </div>
</nav>
`;

// Sidebar
const sidebarHTML = `
<aside class="sidebar">
    <ul class="menu">
        <li><a href="/dashboard"><i class="fas fa-home"></i> Dashboard</a></li>
        <li><a href="/relatorios"><i class="fas fa-chart-line"></i> Relatórios</a></li>
        <li><a href="/metas"><i class="fas fa-bullseye"></i> Metas</a></li>
        <li><a href="/configuracoes"><i class="fas fa-cog"></i> Configurações</a></li>
    </ul>
</aside>
`;

// Injeta navbar e sidebar nos containers
document.getElementById("navbar-container").innerHTML = navbarHTML;
document.getElementById("sidebar-container").innerHTML = sidebarHTML;

// Logout
document.getElementById("logout")?.addEventListener("click", () => {
    localStorage.removeItem("loggedUser");
    window.location.href = "/login";
});

// Ativa o menu correto conforme a URL
const currentPath = window.location.pathname;
const menuLinks = document.querySelectorAll(".sidebar .menu li a");

menuLinks.forEach(link => {
    if (link.getAttribute("href") === currentPath) {
        link.parentElement.classList.add("active");
    } else {
        link.parentElement.classList.remove("active");
    }
});
