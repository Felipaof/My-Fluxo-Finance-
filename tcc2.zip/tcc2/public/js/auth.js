// Função para cadastrar usuário
function cadastrarUsuario(dados) {
  let users = JSON.parse(localStorage.getItem("users")) || [];

  // Verifica se e-mail ou CPF já estão cadastrados
  if (users.some(u => u.email === dados.email || u.cpf === dados.cpf)) {
    mostrarErro("E-mail ou CPF já cadastrado!");
    return false;
  }

  // Salva novo usuário
  users.push(dados);
  localStorage.setItem("users", JSON.stringify(users));

  alert("Cadastro realizado com sucesso!");
  window.location.href = "/login"; // redireciona para a página de login
  return true;
}

// Captura evento do formulário de cadastro
const cadastroForm = document.getElementById("cadastroForm");
if (cadastroForm) {
  cadastroForm.addEventListener("submit", (e) => {
    e.preventDefault();

    const nome = document.getElementById("nome").value.trim();
    const cpf = document.getElementById("cpf").value.trim();
    const email = document.getElementById("email").value.trim();
    const senha = document.getElementById("senha").value;
    const confirmarSenha = document.getElementById("confirmar-senha").value;
    const telefone = document.getElementById("telefone").value.trim();
    const terms = document.getElementById("terms").checked;

    // Validações básicas
    if (!terms) {
      mostrarErro("Você deve aceitar os Termos de Serviço.");
      return;
    }

    if (senha !== confirmarSenha) {
      mostrarErro("As senhas não coincidem!");
      return;
    }

    const dadosUsuario = { nome, cpf, email, senha, telefone };
    cadastrarUsuario(dadosUsuario);
  });
}
// Exibir mensagem de erro
function mostrarErroLogin(msg) {
  const erroDiv = document.getElementById("erro-login");
  erroDiv.textContent = msg;
  erroDiv.style.display = "block";
}

// Função para autenticar usuário
function loginUsuario(email, senha, lembrar) {
  let users = JSON.parse(localStorage.getItem("users")) || [];

  // Verifica se existe usuário
  let user = users.find(u => u.email === email && u.senha === senha);

  if (user) {
    alert("Login realizado com sucesso!");

    // Salva sessão
    localStorage.setItem("loggedUser", JSON.stringify(user));

    // Se marcou "lembrar-me", salva no localStorage
    if (lembrar) {
      localStorage.setItem("rememberMe", email);
    } else {
      localStorage.removeItem("rememberMe");
    }

    // 👉 Redireciona para o dashboard
    window.location.href = "/dashboard";
    return true;
  } else {
    mostrarErroLogin("E-mail ou senha incorretos!");
    return false;
  }
}

// Captura evento do formulário de login
const loginForm = document.getElementById("loginForm");
if (loginForm) {
  loginForm.addEventListener("submit", (e) => {
    e.preventDefault();
    const email = document.getElementById("email").value.trim();
    const senha = document.getElementById("password").value;
    const lembrar = document.getElementById("lembrar-me").checked;

    loginUsuario(email, senha, lembrar);
  });

  // Preenche automaticamente se tiver "lembrar-me"
  const savedEmail = localStorage.getItem("rememberMe");
  if (savedEmail) {
    document.getElementById("email").value = savedEmail;
    document.getElementById("lembrar-me").checked = true;
  }
}
