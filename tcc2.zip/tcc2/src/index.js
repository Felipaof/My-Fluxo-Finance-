import express from "express";
import path from "path";
import { fileURLToPath } from "url";

const app = express();
const PORT = 3000;

app.set('view engine', 'ejs');
app.set('views', './views'); 

// Necessário para resolver __dirname no ES Modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// 1. Servir a pasta "public"
app.use(express.static(path.join(__dirname, "../public")));

// 2. Rotas para servir os HTML da pasta "view"
app.get("/", (req, res) => {
  res.render("index");
});

app.get("/login", (req, res) => {
  res.render("Login");
});

app.get("/cadastro", (req, res) => {
  res.render("cadastro");
});
app.get("/dashboard", (req, res) => {
  res.render("dashboard");
});
app.get("/relatorios", (req, res) => {
  res.render("relatorios");
});
app.get("/metas", (req, res) => {
  res.render("metas");
});
app.get("/configuracoes", (req, res) => {
  res.render("config");
});
app.get("/addtransacao", (req, res) => {
  res.render("addtransacao");
});


// 3. Inicia o servidor
app.listen(PORT, () => {
  console.log(`Servidor rodando em http://localhost:${PORT}`);
});
