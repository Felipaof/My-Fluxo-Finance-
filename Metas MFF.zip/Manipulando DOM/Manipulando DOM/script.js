document.addEventListener('DOMContentLoaded', function() {
    const themeToggle = document.getElementById('theme-toggle');
    const taskInput = document.getElementById('task-input');
    const addTaskButton = document.getElementById('add-task');
    const taskList = document.getElementById('task-list');
    const highlightPriorityButton = document.getElementById('highlight-priority');
    const messageElement = document.getElementById('message');
    const taskCounterElement = document.getElementById('task-counter');

    themeToggle.addEventListener('click', function() {
        document.body.classList.toggle('dark-mode');
        
        if (document.body.classList.contains('dark-mode')) {
            themeToggle.textContent = 'Modo Claro';
        } else {
            themeToggle.textContent = 'Modo Escuro';
        }
    });
    
    addTaskButton.addEventListener('click', addTask);
    taskInput.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            addTask();
        }
    });
    
    function showMessage(message, isError = false) {
        messageElement.textContent = message;
        messageElement.className = isError ? 'message error-message' : 'message success-message';
        
        setTimeout(() => {
            messageElement.style.display = 'none';
        }, 3000);
    }
    
    function updateTaskCounter() {
        const totalTasks = document.querySelectorAll('.task-item').length;
        const completedTasks = document.querySelectorAll('.task-item.completed').length;
        taskCounterElement.textContent = `Total: ${totalTasks} | Concluídas: ${completedTasks}`;
    }
    
    function addTask() {
        const taskText = taskInput.value.trim();
        
        if (taskText === '') {
            showMessage('ERRO! O campo não pode estar vazio.', true);
            return;
        }
        
        const taskItem = document.createElement('li');
        taskItem.className = 'task-item';
        
        const taskSpan = document.createElement('span');
        taskSpan.textContent = taskText;
        
        const taskButtons = document.createElement('div');
        taskButtons.className = 'task-buttons';
        
        const completeButton = document.createElement('button');
        completeButton.className = 'complete-btn';
        completeButton.textContent = 'Concluir';
        
        const deleteButton = document.createElement('button');
        deleteButton.className = 'delete-btn';
        deleteButton.textContent = 'Remover';
        
        const editButton = document.createElement('button');
        editButton.className = 'edit-btn';
        editButton.textContent = 'Editar';
        
        completeButton.addEventListener('click', function() {
            taskItem.classList.toggle('completed');
            updateTaskCounter();
        });
        
        deleteButton.addEventListener('click', function() {
            taskItem.remove();
            updateTaskCounter();
            
            if (taskItem.classList.contains('priority')) {
                removePriorityClass();
            }
        });
        
        editButton.addEventListener('click', function() {
            const currentText = taskSpan.textContent;
            const editInput = document.createElement('input');
            editInput.type = 'text';
            editInput.value = currentText;
            
            const saveButton = document.createElement('button');
            saveButton.className = 'edit-btn';
            saveButton.textContent = 'Salvar';
            
            taskSpan.replaceWith(editInput);
            editButton.replaceWith(saveButton);
            
            saveButton.addEventListener('click', function() {
                const newText = editInput.value.trim();
                if (newText !== '') {
                    taskSpan.textContent = newText;
                    editInput.replaceWith(taskSpan);
                    saveButton.replaceWith(editButton);
                }
            });
        });
        
        taskButtons.appendChild(completeButton);
        taskButtons.appendChild(editButton);
        taskButtons.appendChild(deleteButton);
        taskItem.appendChild(taskSpan);
        taskItem.appendChild(taskButtons);
        taskList.appendChild(taskItem);
        
        taskInput.value = '';
        showMessage('Tarefa adicionada com sucesso!');
        updateTaskCounter();
    }
    
    highlightPriorityButton.addEventListener('click', function() {
        removePriorityClass();
        
        const tasks = document.querySelectorAll('.task-item:not(.completed)');
        if (tasks.length === 0) return;
        
        let longestTask = null;
        let maxLength = 0;
        
        tasks.forEach(task => {
            const taskText = task.querySelector('span').textContent;
            if (taskText.length > maxLength) {
                maxLength = taskText.length;
                longestTask = task;
            }
        });
        
        if (longestTask) {
            longestTask.classList.add('priority');
        }
    });
    
    function removePriorityClass() {
        document.querySelectorAll('.task-item').forEach(task => {
            task.classList.remove('priority');
        });
    }
});